// Setup type definitions for built-in Supabase Runtime APIs
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
Deno.serve(async (req)=>{
  // Solo acepta POST
  if (req.method !== "POST") {
    return new Response(JSON.stringify({
      error: "Método no permitido"
    }), {
      status: 405,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
  try {
    const { tipo, email, nombre, nombreEspacio, motivo, id_registro } = await req.json();
    // Validar campos requeridos
    if (!email || !nombre || !tipo) {
      return new Response(JSON.stringify({
        error: "Campos requeridos faltantes"
      }), {
        status: 400,
        headers: {
          "Content-Type": "application/json"
        }
      });
    }
    // Plantillas de email según tipo
    const templates = {
      confirmacion: {
        subject: "✅ Tu reserva ha sido confirmada",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #28a745;">¡Hola ${nombre}!</h2>
            <p>Tu reserva ha sido <strong>confirmada exitosamente</strong>.</p>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <p><strong>Espacio:</strong> ${nombreEspacio || "No especificado"}</p>
              <p><strong>Registro ID:</strong> ${id_registro || "N/A"}</p>
            </div>
            <p>Puedes proceder con tu uso del espacio. Si tienes preguntas, contáctanos.</p>
            <p style="color: #666; font-size: 12px;">Este es un email automático, por favor no respondas.</p>
          </div>
        `
      },
      rechazo: {
        subject: "❌ Tu reserva ha sido rechazada",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #dc3545;">Hola ${nombre},</h2>
            <p>Lamentablemente, tu reserva ha sido <strong>rechazada</strong>.</p>
            <div style="background: #fff3cd; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ffc107;">
              <p><strong>Motivo:</strong></p>
              <p>${motivo || "No especificado"}</p>
              <p><strong>Registro ID:</strong> ${id_registro || "N/A"}</p>
            </div>
            <p>Puedes intentar hacer una nueva reserva. Si deseas más información, por favor contáctanos.</p>
            <p style="color: #666; font-size: 12px;">Este es un email automático, por favor no respondas.</p>
          </div>
        `
      },
      cancelacion: {
        subject: "⚠️ Tu reserva ha sido cancelada por emergencia",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #ff9800;">Hola ${nombre},</h2>
            <p>Tu reserva ha sido <strong>cancelada por emergencia</strong>.</p>
            <div style="background: #ffe4e1; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ff6347;">
              <p><strong>Motivo:</strong></p>
              <p>${motivo || "No especificado"}</p>
              <p><strong>Espacio:</strong> ${nombreEspacio || "No especificado"}</p>
              <p><strong>Registro ID:</strong> ${id_registro || "N/A"}</p>
            </div>
            <p>Pedimos disculpas por los inconvenientes. Puedes reprogramar tu reserva en cualquier momento.</p>
            <p style="color: #666; font-size: 12px;">Este es un email automático, por favor no respondas.</p>
          </div>
        `
      }
    };
    const template = templates[tipo];
    // Enviar con Resend
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`
      },
      body: JSON.stringify({
        from: "gerardo.pino@up.ac.pa",
        to: email,
        subject: template.subject,
        html: template.html
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("Error de Resend:", data);
      return new Response(JSON.stringify({
        error: data
      }), {
        status: response.status,
        headers: {
          "Content-Type": "application/json"
        }
      });
    }
    return new Response(JSON.stringify({
      success: true,
      data
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error en send-email:", error);
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
});
